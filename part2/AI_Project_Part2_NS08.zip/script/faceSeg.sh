#!/bin/bash
for file in part*/*_1_1*; 
do
    cp "$file" femaleBlack
done
